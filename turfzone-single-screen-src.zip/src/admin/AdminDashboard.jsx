
import { useApp } from "../context/AppContext";

export default function AdminDashboard() {
  const { turfs, bookings, enquiries } = useApp();

  const eligible = bookings.filter((b) => b.status !== "Cancelled");
  const revenue = eligible.reduce((s, b) => s + b.total, 0);

  const cards = [
    ["Total Turfs", turfs.length],
    ["Total Bookings", bookings.length],
    [
      "Pending Bookings",
      bookings.filter((b) => b.status === "Pending").length,
    ],
    [
      "Confirmed Bookings",
      bookings.filter((b) => b.status === "Confirmed").length,
    ],
    [
      "Cancelled Bookings",
      bookings.filter((b) => b.status === "Cancelled").length,
    ],
    ["Total Enquiries", enquiries.length],
    ["Eligible Revenue", `₹${ revenue.toLocaleString("en-IN") } `],
  ];

  return (
    <div className="w-full">
      {/* Header */}
      <div className="mb-6">
        <p className="text-xs font-black uppercase tracking-[0.2em] text-lime-700">
          Admin Dashboard
        </p>

        <div className="mt-1 flex flex-col justify-between gap-2 sm:flex-row sm:items-end">
          <div>
            <h1 className="font-display text-3xl font-bold tracking-tight text-slate-950 sm:text-4xl">
              Operations Overview
            </h1>
            <p className="mt-1 text-sm text-slate-500">
              Monitor your turf bookings and daily operations.
            </p>
          </div>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map(([name, value]) => (
          <div
            key={name}
            className="group rounded-2xl border border-slate-200 bg-white p-4 shadow-[0_2px_12px_rgba(15,23,42,0.04)] transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md"
          >
            <p className="text-[11px] font-bold uppercase tracking-wide text-slate-400">
              {name}
            </p>

            <p className="mt-2 font-display text-2xl font-bold tracking-tight text-slate-950">
              {value}
            </p>

            <div className="mt-3 h-1 w-8 rounded-full bg-lime-400 transition-all duration-200 group-hover:w-12" />
          </div>
        ))}
      </div>

      {/* Bottom Sections */}
      <div className="mt-5 grid gap-5 lg:grid-cols-2">
        
        {/* Recent Bookings */}
        <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-[0_2px_12px_rgba(15,23,42,0.04)]">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-display text-lg font-bold text-slate-950">
                Recent Bookings
              </h2>
              <p className="mt-1 text-xs text-slate-400">
                Latest turf reservations
              </p>
            </div>

            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-lime-100 text-sm font-black text-lime-700">
              {bookings.length}
            </div>
          </div>

          <div className="mt-5 space-y-2.5">
            {bookings
              .slice(-6)
              .reverse()
              .map((b) => (
                <div
                  key={b.id}
                  className="flex items-center justify-between gap-4 rounded-xl border border-slate-100 bg-slate-50 px-4 py-3 transition hover:bg-slate-100"
                >
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-slate-900">
                      {b.turfName}
                    </p>

                    <p className="mt-1 text-xs text-slate-500">
                      {b.date} <span className="mx-1">·</span> {b.sport}
                    </p>
                  </div>

                  <span className="shrink-0 rounded-lg bg-white px-2.5 py-1.5 text-xs font-black text-slate-900 shadow-sm">
                    ₹{b.total}
                  </span>
                </div>
              ))}

            {!bookings.length && (
              <div className="rounded-xl border border-dashed border-slate-200 py-10 text-center">
                <p className="text-sm font-medium text-slate-400">
                  No bookings yet.
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Booking Status */}
        <div className="rounded-2xl bg-slate-950 p-5 text-white shadow-[0_2px_15px_rgba(15,23,42,0.12)]">
          <div>
            <h2 className="font-display text-lg font-bold">
              Booking Status
            </h2>

            <p className="mt-1 text-xs text-slate-400">
              Current booking distribution
            </p>
          </div>

          <div className="mt-6 space-y-5">
            {["Confirmed", "Pending", "Cancelled", "Completed"].map((s) => {
              const n = bookings.filter((b) => b.status === s).length;

              const pct = bookings.length
                ? Math.round((n / bookings.length) * 100)
                : 0;

              return (
                <div key={s}>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-300">
                      {s}
                    </span>

                    <span className="text-xs font-black text-white">
                      {n}
                    </span>
                  </div>

                  <div className="h-2 overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-lime-400 transition-all duration-500"
                      style={{ width: `${ pct }% ` }}
                    />
                  </div>

                  <p className="mt-1 text-right text-[10px] text-slate-500">
                    {pct}%
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

