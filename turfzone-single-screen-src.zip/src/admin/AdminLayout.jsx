
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function AdminLayout() {
  const { setAdmin } = useApp();
  const nav = useNavigate();

  return (
    <main className="min-h-screen bg-slate-100 pt-20">
      <div className="mx-auto grid w-full max-w-[1500px] gap-4 px-3 py-4 sm:px-4 lg:grid-cols-[210px_1fr] lg:px-5 xl:gap-5">
        
        {/* Sidebar */}
        <aside className="rounded-2xl bg-slate-950 p-4 text-white lg:sticky lg:top-24 lg:h-[calc(100vh-116px)]">
          <img
            src="/images/logo.png"
            alt="TurfZone"
            className="mb-5 h-9 w-auto"
          />

          <div className="grid gap-1">
            {[
              ["Dashboard", "/admin"],
              ["Manage Turfs", "/admin/turfs"],
              ["Manage Bookings", "/admin/bookings"],
              ["Manage Enquiries", "/admin/enquiries"],
            ].map(([name, path]) => (
              <NavLink
                end={path === "/admin"}
                key={path}
                to={path}
                className={({ isActive }) =>
                  `rounded - lg px - 3 py - 2.5 text - sm font - bold transition ${
    isActive
        ? "bg-lime-400 text-slate-950"
        : "text-slate-300 hover:bg-white/10 hover:text-white"
} `
                }
              >
                {name}
              </NavLink>
            ))}
          </div>

          <button
            onClick={() => {
              setAdmin({ loggedIn: false });
              nav("/admin/login");
            }}
            className="mt-6 w-full rounded-lg border border-white/10 px-3 py-2.5 text-sm font-bold text-white transition hover:bg-white/10"
          >
            Logout
          </button>
        </aside>

        {/* Main Content */}
        <section className="min-w-0">
          <Outlet />
        </section>
      </div>
    </main>
  );
}

