
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";

export default function SportsCard({ sport, count }) {
  return (
    <motion.div
      whileHover={{ y: -7 }}
      transition={{ duration: 0.25, ease: "easeOut" }}
      className="group relative isolate w-full"
    >
      {/* Animated Glow */}
      <div className="pointer-events-none absolute -inset-[2px] -z-10 rounded-[26px] bg-[linear-gradient(90deg,#a3e635,#facc15,#84cc16,#facc15,#a3e635)] opacity-40 blur-[3px] transition-opacity duration-500 group-hover:opacity-90 animate-[sportGlow_5s_ease-in-out_infinite]" />

      {/* Animated Border */}
      <div className="pointer-events-none absolute -inset-[1px] -z-10 overflow-hidden rounded-[25px]">
        <div className="absolute inset-[-100%] bg-[conic-gradient(from_0deg,transparent_0deg,#a3e635_70deg,#facc15_130deg,transparent_200deg,#a3e635_280deg,transparent_360deg)] opacity-80 animate-[sportBorder_5s_linear_infinite]" />
      </div>

      {/* Card */}
      <div className="relative overflow-hidden rounded-[24px] border border-white/70 bg-white shadow-[0_8px_30px_rgba(15,23,42,0.07)] transition-all duration-500 group-hover:shadow-[0_20px_45px_rgba(15,23,42,0.14)]">
        {/* Image */}
        <div className="relative h-44 overflow-hidden bg-slate-950 sm:h-48 md:h-44 lg:h-48 xl:h-52">
          <img
            src={sport.image}
            alt={sport.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          />

          {/* Image overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/10 to-transparent" />

          {/* Animated shine */}
          <div className="pointer-events-none absolute inset-y-0 -left-[120%] w-[70%] skew-x-[-20deg] bg-gradient-to-r from-transparent via-white/20 to-transparent transition-all duration-1000 group-hover:left-[140%]" />

          {/* Sport badge */}
          <div className="absolute left-3 top-3 sm:left-4 sm:top-4">
            <div className="flex items-center gap-1.5 rounded-full border border-white/20 bg-slate-950/60 px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wider text-white backdrop-blur-md sm:px-3">
              <Sparkles className="h-3 w-3 text-lime-400" />
              Sport
            </div>
          </div>

          {/* Count */}
          <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between sm:bottom-4 sm:left-4 sm:right-4">
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-[0.15em] text-lime-300">
                Available
              </p>

              <p className="mt-0.5 text-sm font-extrabold text-white">
                {count} turf{count !== 1 ? "s" : ""}
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5">
          <h3 className="font-display text-base font-black tracking-tight text-slate-950 sm:text-lg">
            {sport.name}
          </h3>

          <p className="mt-2 min-h-[40px] text-xs leading-5 text-slate-500 sm:text-sm sm:leading-6">
            {sport.description}
          </p>

          {/* Bottom */}
          <div className="mt-4 flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
            <span className="min-w-0 truncate text-[11px] font-extrabold text-lime-700 sm:text-xs">
              {count} available turf{count !== 1 ? "s" : ""}
            </span>

            <Link
              to={`/explore?sport=${encodeURIComponent(sport.id || sport.name)}`}
              className="group/link inline-flex shrink-0 items-center gap-1.5 rounded-xl bg-slate-950 px-3 py-2 text-xs font-extrabold text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-lime-400 hover:text-slate-950 hover:shadow-[0_8px_20px_rgba(163,230,53,0.25)] sm:px-4 sm:text-sm"
            >
              Explore

              <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover/link:translate-x-1" />
            </Link>
          </div>
        </div>

        {/* Bottom animated line */}
        <div className="absolute bottom-0 left-0 h-[2px] w-full overflow-hidden bg-slate-100">
          <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-transparent via-lime-400 to-transparent animate-[sportBottomLine_3s_linear_infinite]" />
        </div>
      </div>

      <style>{`
@keyframes sportBorder {
          from {
    transform: rotate(0deg);
  }

          to {
    transform: rotate(360deg);
  }
}

@keyframes sportGlow {
  0 %,
    100 % {
      opacity: 0.35;
    }

  50 % {
    opacity: 0.65;
  }
}

@keyframes sportBottomLine {
  0 % {
    transform: translateX(-150 %);
  }

  100 % {
    transform: translateX(450 %);
  }
}

@media(prefers - reduced - motion: reduce) {
          .animate -\\[sportBorder_5s_linear_infinite\\],
          .animate -\\[sportGlow_5s_ease -in -out_infinite\\],
          .animate -\\[sportBottomLine_3s_linear_infinite\\] {
    animation: none!important;
  }
}
`}</style>
    </motion.div>
  );
}

