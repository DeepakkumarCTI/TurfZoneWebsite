
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  MapPin,
  Star,
} from "lucide-react";

export default function TurfCard({ turf }) {
  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15 }}
      whileHover={{ y: -7 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className="group relative isolate w-full"
    >
      {/* Animated outer glow */}
      <div className="pointer-events-none absolute -inset-[2px] -z-10 rounded-[27px] bg-[linear-gradient(90deg,#a3e635,#facc15,#84cc16,#facc15,#a3e635)] opacity-35 blur-[3px] transition-opacity duration-500 group-hover:opacity-90 animate-[turfGlow_5s_ease-in-out_infinite]" />

      {/* Animated border */}
      <div className="pointer-events-none absolute -inset-[1px] -z-10 overflow-hidden rounded-[26px]">
        <div className="absolute inset-[-100%] bg-[conic-gradient(from_0deg,transparent_0deg,#a3e635_65deg,#facc15_125deg,transparent_195deg,#84cc16_275deg,transparent_360deg)] opacity-80 animate-[turfBorder_5s_linear_infinite]" />
      </div>

      {/* Main card */}
      <div className="relative overflow-hidden rounded-[25px] border border-white/80 bg-white shadow-[0_8px_30px_rgba(15,23,42,0.07)] transition-all duration-500 group-hover:shadow-[0_20px_50px_rgba(15,23,42,0.15)]">
        {/* Image */}
        <div className="relative h-52 overflow-hidden bg-slate-950 sm:h-56 lg:h-52 xl:h-56">
          <img
            src={turf.image}
            alt={turf.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
          />

          {/* Dark image gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent" />

          {/* Image shine */}
          <div className="pointer-events-none absolute inset-y-0 -left-[120%] w-[65%] skew-x-[-20deg] bg-gradient-to-r from-transparent via-white/20 to-transparent transition-all duration-1000 group-hover:left-[140%]" />

          {/* Top badges */}
          <div className="absolute left-3 right-3 top-3 flex items-center justify-between sm:left-4 sm:right-4 sm:top-4">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-lime-300/30 bg-lime-400 px-3 py-1.5 text-[10px] font-black uppercase tracking-wider text-slate-950 shadow-lg">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Available
            </span>

            <span className="inline-flex items-center gap-1 rounded-full border border-white/20 bg-slate-950/60 px-2.5 py-1.5 text-xs font-bold text-white backdrop-blur-md">
              <Star className="h-3.5 w-3.5 fill-yellow-300 text-yellow-300" />
              {turf.rating}
            </span>
          </div>

          {/* Bottom image content */}
          <div className="absolute bottom-4 left-4 right-4 sm:bottom-5 sm:left-5 sm:right-5">
            <h3 className="font-display text-xl font-black tracking-tight text-white sm:text-2xl">
              {turf.name}
            </h3>

            <div className="mt-1.5 flex items-center gap-1.5 text-xs text-white/75">
              <MapPin className="h-3.5 w-3.5 shrink-0 text-lime-300" />
              <span className="truncate">{turf.location}</span>
            </div>
          </div>

          {/* Desktop Price */}
          <div className="absolute bottom-4 right-4 hidden sm:block">
            <div className="rounded-2xl border border-white/30 bg-white/95 px-3.5 py-2 text-right shadow-xl backdrop-blur-sm">
              <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                Starting
              </p>

              <p className="font-display text-lg font-black text-slate-950">
                ₹{turf.price}
                <span className="text-[10px] font-bold text-slate-500">
                  /hr
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5">
          {/* Mobile price */}
          <div className="mb-4 flex items-center justify-between sm:hidden">
            <div>
              <p className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                Starting Price
              </p>

              <p className="mt-0.5 font-display text-xl font-black text-slate-950">
                ₹{turf.price}
                <span className="ml-1 text-xs font-bold text-slate-500">
                  /hr
                </span>
              </p>
            </div>

            <div className="flex items-center gap-1 rounded-xl bg-amber-50 px-2.5 py-2 text-xs font-black text-amber-700">
              <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
              {turf.rating}
            </div>
          </div>

          {/* Sports */}
          <div className="mb-4">
            <p className="mb-2 text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
              Sports
            </p>

            <div className="flex flex-wrap gap-1.5">
              {turf.sports.slice(0, 3).map((sport) => (
                <span
                  key={sport}
                  className="rounded-lg border border-slate-100 bg-slate-50 px-2.5 py-1.5 text-[11px] font-bold capitalize text-slate-600 transition-colors duration-300 group-hover:border-lime-100 group-hover:bg-lime-50 group-hover:text-lime-700"
                >
                  {sport.replace("-", " ")}
                </span>
              ))}

              {turf.sports.length > 3 && (
                <span className="rounded-lg bg-slate-100 px-2.5 py-1.5 text-[11px] font-bold text-slate-500">
                  +{turf.sports.length - 3}
                </span>
              )}
            </div>
          </div>

          {/* Facilities */}
          <div className="mb-5">
            <p className="mb-2 text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
              Facilities
            </p>

            <div className="flex flex-wrap gap-1.5">
              {turf.facilities.slice(0, 4).map((facility) => (
                <span
                  key={facility}
                  className="rounded-full bg-slate-100 px-2.5 py-1 text-[10px] font-semibold capitalize text-slate-500"
                >
                  {facility.replace("-", " ")}
                </span>
              ))}
            </div>
          </div>

          {/* Buttons */}
          <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
            <Link
              to={`/turf/${turf.id}`}
              className="group/details inline-flex items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-3 text-xs font-extrabold text-slate-700 transition-all duration-300 hover:-translate-y-0.5 hover:border-slate-300 hover:bg-slate-50 hover:shadow-sm sm:text-sm"
            >
              View Details

              <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover/details:translate-x-1" />
            </Link>

            <Link
              to={`/turf/${turf.id}#book`}
              className="group/book relative inline-flex items-center justify-center gap-2 overflow-hidden rounded-xl bg-slate-950 px-3 py-3 text-xs font-extrabold text-white shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:bg-lime-400 hover:text-slate-950 hover:shadow-[0_10px_25px_rgba(163,230,53,0.25)] sm:text-sm"
            >
              <span className="relative z-10">
                Book Now
              </span>

              <ArrowRight className="relative z-10 h-3.5 w-3.5 transition-transform duration-300 group-hover/book:translate-x-1" />

              <span className="absolute inset-0 -translate-x-full bg-white/15 transition-transform duration-700 group-hover/book:translate-x-full" />
            </Link>
          </div>
        </div>

        {/* Animated bottom line */}
        <div className="absolute bottom-0 left-0 h-[2px] w-full overflow-hidden bg-slate-100">
          <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-transparent via-lime-400 to-transparent animate-[turfBottomLine_3s_linear_infinite]" />
        </div>
      </div>

      <style>{`
@keyframes turfBorder {
          from {
    transform: rotate(0deg);
  }

          to {
    transform: rotate(360deg);
  }
}

@keyframes turfGlow {
  0 %,
    100 % {
      opacity: 0.3;
    }

  50 % {
    opacity: 0.65;
  }
}

@keyframes turfBottomLine {
  0 % {
    transform: translateX(-150 %);
  }

  100 % {
    transform: translateX(450 %);
  }
}

@media(prefers - reduced - motion: reduce) {
          .animate -\\[turfBorder_5s_linear_infinite\\],
          .animate -\\[turfGlow_5s_ease -in -out_infinite\\],
          .animate -\\[turfBottomLine_3s_linear_infinite\\] {
    animation: none!important;
  }
}
`}</style>
    </motion.article>
  );
}

