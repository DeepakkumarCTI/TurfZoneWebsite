import { useState } from "react";
import { Link } from "react-router-dom";
import { company } from "../data/company";

export default function Footer() {
    const [modal, setModal] = useState(null);

    const quickLinks = [
        ["Our Turf", "/explore"],
        ["Sports", "/sports"],
        ["My Bookings", "/bookings"],
        ["About Us", "/about"],
        ["Contact Us", "/contact"],
    ];

    const sports = [
        "Football",
        "Cricket",
        "Box Cricket",
        "Badminton",
        "Basketball",
    ];

    return (
        <>
            {/* =========================================================
                FOOTER
            ========================================================= */}
            <footer className="relative w-full overflow-hidden bg-slate-950 text-white">

                {/* =====================================================
                    BACKGROUND GLOW
                ===================================================== */}

                <div
                    className="
                        pointer-events-none
                        absolute -left-24 top-16
                        h-56 w-56
                        rounded-full
                        bg-lime-400/10
                        blur-3xl
                        animate-[footerGlow_6s_ease-in-out_infinite]
                    "
                />

                <div
                    className="
                        pointer-events-none
                        absolute -right-24 bottom-10
                        h-64 w-64
                        rounded-full
                        bg-yellow-300/5
                        blur-3xl
                        animate-[footerGlow_7s_ease-in-out_infinite_reverse]
                    "
                />

                {/* =====================================================
                    FLOATING PARTICLES
                ===================================================== */}

                <div className="pointer-events-none absolute inset-0 overflow-hidden">

                    <span
                        className="
                            absolute left-[12%] top-[30%]
                            h-1 w-1 rounded-full
                            bg-lime-300/40
                            animate-[particleFloat_5s_ease-in-out_infinite]
                        "
                    />

                    <span
                        className="
                            absolute left-[45%] top-[65%]
                            h-1 w-1 rounded-full
                            bg-yellow-300/30
                            animate-[particleFloat_7s_ease-in-out_infinite_1s]
                        "
                    />

                    <span
                        className="
                            absolute right-[25%] top-[25%]
                            h-1.5 w-1.5 rounded-full
                            bg-lime-300/30
                            animate-[particleFloat_6s_ease-in-out_infinite_2s]
                        "
                    />

                    <span
                        className="
                            absolute right-[8%] bottom-[25%]
                            h-1 w-1 rounded-full
                            bg-yellow-300/30
                            animate-[particleFloat_8s_ease-in-out_infinite]
                        "
                    />
                </div>

                {/* =====================================================
                    TOP ANIMATED LINE
                ===================================================== */}

                <div className="relative h-[2px] w-full overflow-hidden bg-white/5">

                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-lime-400/10 to-transparent" />

                    <div
                        className="
                            absolute top-0 h-full
                            w-[20%] min-w-[120px]
                            rounded-full
                            bg-gradient-to-r
                            from-transparent
                            via-lime-400
                            to-transparent
                            shadow-[0_0_14px_rgba(163,230,53,0.9)]
                            animate-[footerLine_3.5s_linear_infinite]
                        "
                    />

                    <div
                        className="
                            absolute top-0 h-full
                            w-[10%] min-w-[70px]
                            rounded-full
                            bg-gradient-to-r
                            from-transparent
                            via-yellow-300
                            to-transparent
                            animate-[footerLine_5s_linear_infinite_1s]
                        "
                    />
                </div>

                {/* =====================================================
                    MAIN FOOTER CONTENT
                ===================================================== */}

                <div className="relative w-full px-5 py-9 sm:px-6 sm:py-10 lg:px-8">

                    <div
                        className="
                            grid w-full
                            grid-cols-1
                            gap-9
                            sm:grid-cols-2
                            lg:grid-cols-4
                            lg:gap-8
                        "
                    >

                        {/* =================================================
                            COLUMN 1 - BRAND
                        ================================================= */}

                        <div className="animate-[footerItem_0.7s_ease-out]">

                            {/* Logo + Name */}

                            <Link
                                to="/"
                                className="
                                    group
                                    inline-flex
                                    items-center
                                    gap-3
                                "
                            >

                                <div className="relative">

                                    {/* Logo Glow */}

                                    <div
                                        className="
                                            absolute inset-0
                                            rounded-full
                                            bg-lime-400/20
                                            blur-2xl
                                            transition-all duration-500
                                            group-hover:scale-125
                                            group-hover:bg-lime-400/30
                                        "
                                    />

                                    <img
                                        src="/images/logo.png"
                                        alt={company.name}
                                        className="
                                            relative
                                            h-11 w-auto
                                            object-contain
                                            transition-all duration-500
                                            group-hover:scale-110
                                            animate-[logoFloat_3s_ease-in-out_infinite]
                                        "
                                    />
                                </div>

                                <div>

                                    <h2
                                        className="
                                            font-display
                                            text-lg
                                            font-extrabold
                                            tracking-tight
                                            text-white
                                        "
                                    >
                                        {company.name}
                                    </h2>

                                    <div
                                        className="
                                            mt-1
                                            h-0.5
                                            w-10
                                            overflow-hidden
                                            rounded-full
                                            bg-lime-400
                                        "
                                    >
                                        <div
                                            className="
                                                h-full
                                                w-full
                                                bg-yellow-300
                                                animate-[brandLine_2s_ease-in-out_infinite]
                                            "
                                        />
                                    </div>

                                </div>

                            </Link>

                            {/* Description */}

                            <p
                                className="
                                    mt-4
                                    max-w-sm
                                    text-sm
                                    leading-6
                                    text-slate-400
                                "
                            >
                                {company.description}
                            </p>

                            {/* Social Icons */}

                            <div className="mt-5 flex items-center gap-2.5">

                                {/* Instagram */}

                                <a
                                    href="#"
                                    aria-label="Instagram"
                                    className="
                                        group
                                        flex h-9 w-9
                                        items-center justify-center
                                        rounded-xl
                                        border border-white/10
                                        bg-white/5
                                        text-slate-400
                                        transition-all duration-300
                                        hover:-translate-y-1
                                        hover:rotate-3
                                        hover:border-lime-400/30
                                        hover:bg-lime-400
                                        hover:text-slate-950
                                        hover:shadow-[0_0_20px_rgba(163,230,53,0.25)]
                                    "
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        className="h-[18px] w-[18px]"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth="1.8"
                                    >
                                        <rect
                                            x="3"
                                            y="3"
                                            width="18"
                                            height="18"
                                            rx="5"
                                        />

                                        <circle
                                            cx="12"
                                            cy="12"
                                            r="4"
                                        />

                                        <circle
                                            cx="17.5"
                                            cy="6.5"
                                            r="1"
                                            fill="currentColor"
                                            stroke="none"
                                        />
                                    </svg>
                                </a>

                                {/* Facebook */}

                                <a
                                    href="#"
                                    aria-label="Facebook"
                                    className="
                                        group
                                        flex h-9 w-9
                                        items-center justify-center
                                        rounded-xl
                                        border border-white/10
                                        bg-white/5
                                        text-slate-400
                                        transition-all duration-300
                                        hover:-translate-y-1
                                        hover:-rotate-3
                                        hover:border-lime-400/30
                                        hover:bg-lime-400
                                        hover:text-slate-950
                                        hover:shadow-[0_0_20px_rgba(163,230,53,0.25)]
                                    "
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        className="h-[18px] w-[18px]"
                                        fill="currentColor"
                                    >
                                        <path d="M14 8h3V4h-3c-3.31 0-5 1.69-5 5v3H6v4h3v6h4v-6h3.2l.8-4H13V9c0-.67.33-1 1-1Z" />
                                    </svg>
                                </a>

                                {/* WhatsApp */}

                                <a
                                    href="#"
                                    aria-label="WhatsApp"
                                    className="
                                        group
                                        flex h-9 w-9
                                        items-center justify-center
                                        rounded-xl
                                        border border-white/10
                                        bg-white/5
                                        text-slate-400
                                        transition-all duration-300
                                        hover:-translate-y-1
                                        hover:rotate-3
                                        hover:border-lime-400/30
                                        hover:bg-lime-400
                                        hover:text-slate-950
                                        hover:shadow-[0_0_20px_rgba(163,230,53,0.25)]
                                    "
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        className="h-[18px] w-[18px]"
                                        fill="none"
                                        stroke="currentColor"
                                        strokeWidth="1.8"
                                    >
                                        <path d="M20 11.5a8 8 0 0 1-11.7 7.1L4 20l1.4-4.1A8 8 0 1 1 20 11.5Z" />

                                        <path d="M9 8.5c.2-.4.4-.4.7-.4h.5c.2 0 .4.1.5.4l.6 1.4c.1.2.1.4-.1.6l-.5.6c-.1.1-.1.3 0 .5.5.9 1.3 1.6 2.2 2.1.2.1.4.1.5-.1l.6-.7c.1-.2.4-.2.6-.1l1.4.7c.2.1.3.3.2.6-.2.8-.8 1.3-1.6 1.4-1.3.1-3.1-.7-4.5-2-1.3-1.2-2.1-2.6-2.3-3.7-.1-.5.1-1 .5-1.3Z" />
                                    </svg>
                                </a>

                                {/* X */}

                                <a
                                    href="#"
                                    aria-label="X"
                                    className="
                                        group
                                        flex h-9 w-9
                                        items-center justify-center
                                        rounded-xl
                                        border border-white/10
                                        bg-white/5
                                        text-slate-400
                                        transition-all duration-300
                                        hover:-translate-y-1
                                        hover:-rotate-3
                                        hover:border-lime-400/30
                                        hover:bg-lime-400
                                        hover:text-slate-950
                                        hover:shadow-[0_0_20px_rgba(163,230,53,0.25)]
                                    "
                                >
                                    <svg
                                        viewBox="0 0 24 24"
                                        className="h-4 w-4"
                                        fill="currentColor"
                                    >
                                        <path d="M18.9 2H22l-6.77 7.74L23.2 22h-6.24l-4.89-6.39L6.49 22H3.38l7.24-8.28L2.8 2h6.4l4.42 5.84L18.9 2Zm-1.1 17.86h1.73L8.27 4.04H6.41L17.8 19.86Z" />
                                    </svg>
                                </a>

                            </div>
                        </div>

                        {/* =================================================
                            COLUMN 2 - QUICK LINKS
                        ================================================= */}

                        <div
                            className="
                                animate-[footerItem_0.7s_ease-out_0.1s_both]
                            "
                        >

                            <h3
                                className="
                                    mb-4
                                    font-display
                                    text-base
                                    font-bold
                                    text-white
                                "
                            >
                                Quick Links
                            </h3>

                            <div className="grid gap-2.5">

                                {quickLinks.map(([name, path]) => (
                                    <Link
                                        key={path}
                                        to={path}
                                        className="
                                            group
                                            flex items-center gap-2
                                            text-sm
                                            text-slate-400
                                            transition-all duration-300
                                            hover:translate-x-1
                                            hover:text-lime-300
                                        "
                                    >

                                        <span
                                            className="
                                                h-1 w-1
                                                shrink-0
                                                rounded-full
                                                bg-slate-600
                                                transition-all duration-300
                                                group-hover:w-3
                                                group-hover:bg-lime-400
                                            "
                                        />

                                        {name}

                                    </Link>
                                ))}

                            </div>
                        </div>

                        {/* =================================================
                            COLUMN 3 - SPORTS
                        ================================================= */}

                        <div
                            className="
                                animate-[footerItem_0.7s_ease-out_0.2s_both]
                            "
                        >

                            <h3
                                className="
                                    mb-4
                                    font-display
                                    text-base
                                    font-bold
                                    text-white
                                "
                            >
                                Our Sports
                            </h3>

                            <div className="grid gap-2.5">

                                {sports.map((sport) => (
                                    <Link
                                        key={sport}
                                        to="/sports"
                                        className="
                                            group
                                            flex items-center gap-2
                                            text-sm
                                            text-slate-400
                                            transition-all duration-300
                                            hover:translate-x-1
                                            hover:text-lime-300
                                        "
                                    >

                                        <span
                                            className="
                                                h-1 w-1
                                                shrink-0
                                                rounded-full
                                                bg-slate-600
                                                transition-all duration-300
                                                group-hover:w-3
                                                group-hover:bg-lime-400
                                            "
                                        />

                                        {sport}

                                    </Link>
                                ))}

                            </div>
                        </div>

                        {/* =================================================
                            COLUMN 4 - IMAGE
                        ================================================= */}

                        <div
                            className="
                                animate-[footerItem_0.7s_ease-out_0.3s_both]
                            "
                        >

                            <h3
                                className="
                                    mb-4
                                    font-display
                                    text-base
                                    font-bold
                                    text-white
                                "
                            >
                                Play With Us
                            </h3>

                            {/* Image Container */}

                            <div
                                className="
                                    group
                                    relative
                                    h-40
                                    w-full
                                    overflow-hidden
                                    rounded-2xl
                                    border
                                    border-white/10
                                    bg-white/5
                                    shadow-[0_10px_35px_rgba(0,0,0,0.25)]
                                "
                            >

                                {/* Replace this image later */}

                                <img
                                    src="/images/footer-turf.jpg"
                                    alt="TurfZone"
                                    className="
                                        h-full
                                        w-full
                                        object-cover
                                        transition-all
                                        duration-700
                                        group-hover:scale-110
                                    "
                                />

                                {/* Dark overlay */}

                                <div
                                    className="
                                        absolute inset-0
                                        bg-gradient-to-t
                                        from-slate-950/80
                                        via-slate-950/20
                                        to-transparent
                                    "
                                />

                                {/* Animated glow */}

                                <div
                                    className="
                                        absolute
                                        -bottom-10
                                        -left-10
                                        h-24
                                        w-24
                                        rounded-full
                                        bg-lime-400/20
                                        blur-2xl
                                        transition-all
                                        duration-500
                                        group-hover:scale-150
                                    "
                                />

                                {/* Text */}

                                <div
                                    className="
                                        absolute
                                        bottom-3
                                        left-3
                                        right-3
                                    "
                                >

                                    <p
                                        className="
                                            text-xs
                                            font-bold
                                            uppercase
                                            tracking-[0.15em]
                                            text-lime-300
                                        "
                                    >
                                        TurfZone
                                    </p>

                                    <p className="mt-1 text-sm font-semibold text-white">
                                        Book. Play. Enjoy.
                                    </p>

                                </div>

                            </div>

                        </div>
                    </div>
                </div>

                {/* =====================================================
                    BOTTOM BAR
                ===================================================== */}

                <div
                    className="
                        relative
                        w-full
                        border-t
                        border-white/10
                    "
                >

                    {/* Moving bottom line */}

                    <div
                        className="
                            absolute
                            left-0
                            top-0
                            h-px
                            w-full
                            overflow-hidden
                        "
                    >

                        <div
                            className="
                                absolute
                                top-0
                                h-full
                                w-32
                                bg-gradient-to-r
                                from-transparent
                                via-lime-400
                                to-transparent
                                animate-[footerBottomLine_4s_linear_infinite]
                            "
                        />

                    </div>

                    <div
                        className="
                            flex
                            w-full
                            flex-col
                            items-center
                            justify-between
                            gap-3
                            px-5
                            py-4
                            text-center
                            sm:flex-row
                            sm:text-left
                            lg:px-8
                        "
                    >

                        <p className="text-[11px] text-slate-500">
                            © 2026 {company.name}. Frontend booking simulation using Local Storage.
                        </p>

                        <div
                            className="
                                flex
                                flex-wrap
                                items-center
                                justify-center
                                gap-x-4
                                gap-y-2
                            "
                        >

                            <button
                                type="button"
                                onClick={() => setModal("privacy")}
                                className="
                                    text-[11px]
                                    font-semibold
                                    text-slate-500
                                    transition-colors
                                    duration-300
                                    hover:text-lime-300
                                "
                            >
                                Privacy Policy
                            </button>

                            <span className="h-1 w-1 rounded-full bg-slate-700" />

                            <button
                                type="button"
                                onClick={() => setModal("terms")}
                                className="
                                    text-[11px]
                                    font-semibold
                                    text-slate-500
                                    transition-colors
                                    duration-300
                                    hover:text-lime-300
                                "
                            >
                                Terms & Conditions
                            </button>

                        </div>

                    </div>
                </div>

                {/* =====================================================
                    ANIMATIONS
                ===================================================== */}

                <style>{`

                    @keyframes footerLine {
                        0% {
                            transform: translateX(-150%);
                        }

                        100% {
                            transform: translateX(550%);
                        }
                    }

                    @keyframes footerBottomLine {
                        0% {
                            transform: translateX(-150%);
                        }

                        100% {
                            transform: translateX(900%);
                        }
                    }

                    @keyframes footerGlow {
                        0%, 100% {
                            transform: scale(0.9);
                            opacity: 0.25;
                        }

                        50% {
                            transform: scale(1.15);
                            opacity: 0.65;
                        }
                    }

                    @keyframes footerItem {
                        from {
                            opacity: 0;
                            transform: translateY(18px);
                        }

                        to {
                            opacity: 1;
                            transform: translateY(0);
                        }
                    }

                    @keyframes logoFloat {
                        0%, 100% {
                            transform: translateY(0);
                        }

                        50% {
                            transform: translateY(-4px);
                        }
                    }

                    @keyframes brandLine {
                        0% {
                            transform: translateX(-100%);
                        }

                        50% {
                            transform: translateX(0);
                        }

                        100% {
                            transform: translateX(100%);
                        }
                    }

                    @keyframes particleFloat {
                        0%, 100% {
                            transform: translateY(0) scale(1);
                            opacity: 0.25;
                        }

                        50% {
                            transform: translateY(-18px) scale(1.5);
                            opacity: 0.8;
                        }
                    }

                    @media (prefers-reduced-motion: reduce) {
                        *,
                        *::before,
                        *::after {
                            animation-duration: 0.01ms !important;
                            animation-iteration-count: 1 !important;
                            scroll-behavior: auto !important;
                        }
                    }

                `}</style>

            </footer>

            {/* =========================================================
                PRIVACY / TERMS MODAL
            ========================================================= */}

            <AnimateModal
                type={modal}
                close={() => setModal(null)}
            />
        </>
    );
}


/* =============================================================
   MODAL COMPONENT
============================================================= */

function AnimateModal({ type, close }) {

    if (!type) return null;

    const privacy = type === "privacy";

    return (
        <div
            className="
                fixed
                inset-0
                z-[100]
                flex
                items-center
                justify-center
                bg-slate-950/80
                px-4
                py-6
                backdrop-blur-md
                animate-[modalOverlay_.25s_ease-out]
            "
            onClick={close}
        >

            <div
                className="
                    relative
                    max-h-[85vh]
                    w-full
                    max-w-2xl
                    overflow-hidden
                    rounded-3xl
                    border
                    border-white/10
                    bg-slate-900
                    text-white
                    shadow-[0_25px_80px_rgba(0,0,0,0.55)]
                    animate-[modalIn_.35s_ease-out]
                "
                onClick={(e) => e.stopPropagation()}
            >

                {/* Animated line */}

                <div className="relative h-[2px] overflow-hidden bg-white/5">

                    <div
                        className="
                            absolute
                            inset-y-0
                            h-full
                            w-1/3
                            bg-gradient-to-r
                            from-transparent
                            via-lime-400
                            to-transparent
                            animate-[modalLine_2.5s_linear_infinite]
                        "
                    />

                </div>

                {/* Header */}

                <div
                    className="
                        flex
                        items-center
                        justify-between
                        border-b
                        border-white/10
                        px-5
                        py-4
                        sm:px-7
                    "
                >

                    <div>

                        <p
                            className="
                                text-[10px]
                                font-black
                                uppercase
                                tracking-[0.2em]
                                text-lime-300
                            "
                        >
                            {company.name}
                        </p>

                        <h2 className="mt-1 font-display text-xl font-bold sm:text-2xl">
                            {privacy
                                ? "Privacy Policy"
                                : "Terms & Conditions"}
                        </h2>

                    </div>

                    <button
                        type="button"
                        onClick={close}
                        aria-label="Close"
                        className="
                            flex
                            h-9
                            w-9
                            items-center
                            justify-center
                            rounded-xl
                            border
                            border-white/10
                            bg-white/5
                            text-xl
                            text-slate-400
                            transition-all
                            duration-300
                            hover:rotate-90
                            hover:bg-lime-400
                            hover:text-slate-950
                        "
                    >
                        ×
                    </button>

                </div>

                {/* Content */}

                <div
                    className="
                        max-h-[65vh]
                        overflow-y-auto
                        px-5
                        py-5
                        sm:px-7
                    "
                >

                    {privacy ? (

                        <div className="space-y-5 text-sm leading-6 text-slate-400">

                            <PolicySection title="1. Information We Collect">
                                TurfZone may collect information provided during
                                the booking process, such as your name, phone
                                number, email address, selected turf, booking
                                date and selected time slot.
                            </PolicySection>

                            <PolicySection title="2. How We Use Your Information">
                                The information is used to process bookings,
                                communicate booking updates, respond to
                                enquiries and provide a better booking experience.
                            </PolicySection>

                            <PolicySection title="3. Booking Information">
                                Booking information is used for managing your
                                turf reservations and related customer support.
                            </PolicySection>

                            <PolicySection title="4. Local Storage">
                                This frontend demo uses browser Local Storage
                                to maintain booking and application state.
                                Clearing browser storage may remove locally
                                stored demo data.
                            </PolicySection>

                            <PolicySection title="5. Data Protection">
                                We aim to handle submitted information
                                responsibly and use reasonable measures to
                                protect information used within the booking
                                application.
                            </PolicySection>

                            <PolicySection title="6. Contact">
                                If you have questions regarding this Privacy
                                Policy, please contact {company.name} using
                                the contact information provided on this website.
                            </PolicySection>

                        </div>

                    ) : (

                        <div className="space-y-5 text-sm leading-6 text-slate-400">

                            <PolicySection title="1. Booking">
                                Customers are responsible for providing accurate
                                information while making a turf booking.
                            </PolicySection>

                            <PolicySection title="2. Slot Availability">
                                A booking is subject to the availability of the
                                selected turf, date and time slot.
                            </PolicySection>

                            <PolicySection title="3. Booking Confirmation">
                                A booking request may remain pending until it
                                is confirmed according to the booking system.
                            </PolicySection>

                            <PolicySection title="4. Cancellation">
                                Cancellation rules may depend on the booking
                                conditions applicable to the selected turf and slot.
                            </PolicySection>

                            <PolicySection title="5. Customer Responsibility">
                                Customers are expected to use the facilities
                                responsibly and follow the rules communicated
                                by the turf management.
                            </PolicySection>

                            <PolicySection title="6. Website Usage">
                                Users should not attempt to misuse, disrupt or
                                interfere with the normal operation of the website.
                            </PolicySection>

                            <PolicySection title="7. Changes">
                                {company.name} may update these terms when
                                required. Updated terms will be displayed
                                through the website.
                            </PolicySection>

                            <PolicySection title="8. Contact">
                                For questions regarding these terms, please
                                contact {company.name} using the contact
                                information available on the website.
                            </PolicySection>

                        </div>

                    )}

                </div>

                {/* Modal Footer */}

                <div className="border-t border-white/10 px-5 py-4 sm:px-7">

                    <button
                        type="button"
                        onClick={close}
                        className="
                            w-full
                            rounded-xl
                            bg-lime-400
                            px-5
                            py-2.5
                            text-sm
                            font-black
                            text-slate-950
                            transition-all
                            duration-300
                            hover:-translate-y-0.5
                            hover:bg-lime-300
                            hover:shadow-[0_0_25px_rgba(163,230,53,0.25)]
                        "
                    >
                        Close
                    </button>

                </div>

                <style>{`

                    @keyframes modalOverlay {
                        from {
                            opacity: 0;
                        }

                        to {
                            opacity: 1;
                        }
                    }

                    @keyframes modalIn {
                        from {
                            opacity: 0;
                            transform: translateY(20px) scale(0.96);
                        }

                        to {
                            opacity: 1;
                            transform: translateY(0) scale(1);
                        }
                    }

                    @keyframes modalLine {
                        from {
                            transform: translateX(-150%);
                        }

                        to {
                            transform: translateX(450%);
                        }
                    }

                `}</style>

            </div>
        </div>
    );
}


/* =============================================================
   POLICY SECTION
============================================================= */

function PolicySection({ title, children }) {

    return (
        <section>

            <h3 className="font-display text-sm font-bold text-white sm:text-base">
                {title}
            </h3>

            <p className="mt-1.5">
                {children}
            </p>

        </section>
    );
}