import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { useState } from "react";

import { useApp } from "../context/AppContext";
import { sports } from "../data/sports";
import { company } from "../data/company";

import TurfCard from "../components/TurfCard";
import SportsCard from "../components/SportsCard";

export default function Home() {
    const { turfs } = useApp();
    const navigate = useNavigate();

    const [form, setForm] = useState({
        sport: "",
        date: "",
    });

    const submit = (e) => {
        e.preventDefault();

        const params = new URLSearchParams();

        if (form.sport) {
            params.set("sport", form.sport);
        }

        if (form.date) {
            params.set("date", form.date);
        }

        navigate(`/explore?${params.toString()}`);
    };

    /*
     * Collect all sports available across all facilities
     * managed by this company.
     */
    const availableSportIds = [
        ...new Set(turfs.flatMap((turf) => turf.sports || [])),
    ];

    const availableSports = sports.filter((sport) =>
        availableSportIds.includes(sport.id)
    );

    return (
        <main>
            {/* =========================================================
                HERO
            ========================================================= */}
            <section className="relative isolate min-h-[88svh] overflow-hidden bg-slate-950">

                <video
                    className="absolute inset-0 h-full w-full object-cover"
                    autoPlay
                    muted
                    loop
                    playsInline
                    poster="/images/hero-fallback.png"
                >
                    <source
                        src="/videos/hero-video.mp4"
                        type="video/mp4"
                    />
                </video>

                <img
                    src="/images/hero-fallback.png"
                    alt="TurfZone sports arena"
                    className="absolute inset-0 -z-10 h-full w-full object-cover"
                />

                <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/65 to-slate-950/35" />

                <div
                    className="absolute inset-0 opacity-30"
                    style={{
                        backgroundImage:
                            "linear-gradient(rgba(163,230,53,.2) 1px,transparent 1px),linear-gradient(90deg,rgba(163,230,53,.2) 1px,transparent 1px)",
                        backgroundSize: "80px 80px",
                    }}
                />

                <div className="relative mx-auto flex min-h-[88svh] max-w-[1400px] items-center px-3 pb-28 pt-24 sm:px-5 sm:pb-28 sm:pt-24 lg:px-6 lg:pb-28 lg:pt-24">

                    <div className="max-w-4xl">

                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            className="text-xs font-black uppercase tracking-[.28em] text-lime-300"
                        >
                            {company.name}
                        </motion.p>

                        <motion.h1
                            initial={{ opacity: 0, y: 25 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.1 }}
                            className="mt-4 font-display text-5xl font-black leading-[.95] text-white sm:text-7xl lg:text-8xl"
                        >
                            Your Game.
                            <br />
                            <span className="text-gradient">
                                Your Turf.
                            </span>
                            <br />
                            Your Time.
                        </motion.h1>

                        <motion.p
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.2 }}
                            className="mt-6 max-w-2xl text-sm leading-6 text-slate-200 sm:text-lg sm:leading-7"
                        >
                            {company.description}
                        </motion.p>

                        <div className="mt-7 flex flex-wrap gap-3">

                            <Link
                                to="/explore"
                                className="rounded-xl bg-gradient-to-r from-lime-400 to-yellow-300 px-5 py-3 font-extrabold text-slate-950 transition hover:-translate-y-1 sm:px-6 sm:py-3.5"
                            >
                                Book Your Slot
                            </Link>

                            <Link
                                to="/about"
                                className="rounded-xl border border-white/20 bg-white/10 px-5 py-3 font-bold text-white backdrop-blur transition hover:bg-white/20 sm:px-6 sm:py-3.5"
                            >
                                About Our Arena
                            </Link>

                        </div>

                    </div>
                </div>


                {/* SEARCH */}
                <div className="absolute inset-x-3 bottom-3 z-10 mx-auto max-w-6xl rounded-2xl border border-white/15 bg-slate-950/75 p-3 shadow-2xl backdrop-blur-xl sm:inset-x-5 sm:bottom-4 sm:rounded-3xl sm:p-4 lg:px-5">

                    <form
                        onSubmit={submit}
                        className="grid gap-2.5 md:grid-cols-[1fr_1fr_1fr_auto]"
                    >

                        <select
                            required
                            value={form.sport}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    sport: e.target.value,
                                })
                            }
                            className="rounded-xl bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:ring-2 focus:ring-lime-400"
                        >
                            <option value="">
                                Select Sport
                            </option>

                            {availableSports.map((sport) => (
                                <option
                                    key={sport.id}
                                    value={sport.id}
                                >
                                    {sport.name}
                                </option>
                            ))}
                        </select>

                        <input
                            required
                            type="date"
                            min={new Date().toISOString().slice(0, 10)}
                            value={form.date}
                            onChange={(e) =>
                                setForm({
                                    ...form,
                                    date: e.target.value,
                                })
                            }
                            className="rounded-xl bg-white px-4 py-3 text-sm font-semibold text-slate-700 outline-none focus:ring-2 focus:ring-lime-400"
                        />

                        <div className="flex min-h-[46px] items-center rounded-xl bg-white px-4 py-3 text-sm font-semibold text-slate-700">
                            {company.address}
                        </div>

                        <button
                            type="submit"
                            className="rounded-xl bg-lime-400 px-5 py-3 font-extrabold text-slate-950 transition hover:bg-lime-300 hover:-translate-y-0.5"
                        >
                            Find Slot
                        </button>

                    </form>
                </div>

            </section>


            {/* =========================================================
                STATS
            ========================================================= */}
            <section className="bg-slate-950 px-3 pb-12 pt-3 sm:px-5 sm:pb-14 sm:pt-4 lg:px-6">

                <div className="mx-auto grid max-w-[1400px] grid-cols-2 gap-2.5 sm:grid-cols-4 sm:gap-3">

                    <Stat
                        n={turfs.length}
                        t={
                            turfs.length === 1
                                ? "Main Facility"
                                : "Facilities"
                        }
                    />

                    <Stat
                        n={`${availableSports.length}+`}
                        t="Sports Available"
                    />

                    <Stat
                        n="5000+"
                        t="Demo Player Visits"
                    />

                    <Stat
                        n="06 AM–11 PM"
                        t="Open Daily"
                    />

                </div>

            </section>


            {/* =========================================================
                SPORTS
            ========================================================= */}
            <section className="bg-slate-50 px-3 py-12 sm:px-5 sm:py-14 lg:px-6">

                <div className="mx-auto max-w-[1400px]">

                    <SectionTitle
                        eyebrow="Sports at our company"
                        title="Choose your game."
                    />

                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">

                        {availableSports.map((sport) => (
                            <SportsCard
                                key={sport.id}
                                sport={sport}
                                count={
                                    turfs.filter((turf) =>
                                        turf.sports?.includes(
                                            sport.id
                                        )
                                    ).length
                                }
                            />
                        ))}

                    </div>

                </div>

            </section>


            {/* =========================================================
                ALL COMPANY TURFS
            ========================================================= */}
            <section className="px-3 py-12 sm:px-5 sm:py-14 lg:px-6">

                <div className="mx-auto max-w-[1400px]">

                    <SectionTitle
                        eyebrow="Our facilities"
                        title="Choose your playing space."
                    />

                    {turfs.length === 0 ? (

                        <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 px-5 py-12 text-center">

                            <h3 className="font-display text-2xl font-bold text-slate-900">
                                No facilities available
                            </h3>

                            <p className="mt-2 text-slate-500">
                                Add a facility from the admin panel.
                            </p>

                        </div>

                    ) : (

                        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">

                            {turfs.map((turf) => (
                                <TurfCard
                                    key={turf.id}
                                    turf={turf}
                                />
                            ))}

                        </div>

                    )}

                </div>

            </section>


            {/* =========================================================
                WHY CHOOSE US
            ========================================================= */}
            <section className="bg-slate-950 px-3 py-12 text-white sm:px-5 sm:py-14 lg:px-6">

                <div className="mx-auto max-w-[1400px]">

                    <SectionTitle
                        dark
                        eyebrow="Why choose us"
                        title="A focused sports experience."
                    />

                    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">

                        {[
                            "Easy Online Booking",
                            "Clear Slot Availability",
                            "Quality Playing Surface",
                            "Professional Floodlights",
                            "Player Facilities",
                            "Direct WhatsApp Support",
                        ].map((item, index) => (

                            <motion.div
                                whileInView={{
                                    opacity: [0, 1],
                                    y: [20, 0],
                                }}
                                viewport={{ once: true }}
                                key={item}
                                className="rounded-2xl border border-white/10 bg-white/5 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-lime-400/30 hover:bg-white/10 sm:rounded-3xl sm:p-6"
                            >

                                <span className="text-sm font-black text-lime-300">
                                    {String(index + 1).padStart(2, "0")}
                                </span>

                                <h3 className="mt-4 font-display text-lg font-bold sm:mt-6 sm:text-xl">
                                    {item}
                                </h3>

                                <p className="mt-2 text-sm leading-6 text-slate-400">
                                    Designed around the needs of players booking{" "}
                                    {company.name}.
                                </p>

                            </motion.div>

                        ))}

                    </div>

                </div>

            </section>


            {/* =========================================================
                CTA
            ========================================================= */}
            <section className="px-3 py-10 sm:px-5 sm:py-12 lg:px-6">

                <div className="mx-auto max-w-[1400px] overflow-hidden rounded-[1.5rem] bg-gradient-to-r from-lime-400 via-yellow-300 to-orange-400 p-6 text-slate-950 sm:rounded-[2rem] sm:p-10">

                    <div className="flex flex-col items-start justify-between gap-5 md:flex-row md:items-center">

                        <div>

                            <p className="text-[11px] font-black uppercase tracking-[.2em]">
                                Ready to play?
                            </p>

                            <h2 className="mt-1.5 font-display text-3xl font-bold sm:text-4xl">
                                Book your slot at {company.name}.
                            </h2>

                        </div>

                        <Link
                            to="/explore"
                            className="rounded-xl bg-slate-950 px-5 py-3 font-extrabold text-white transition hover:-translate-y-1 sm:px-6 sm:py-3.5"
                        >
                            Book Your Turf Today
                        </Link>

                    </div>

                </div>

            </section>

        </main>
    );
}


/* =========================================================
   STAT COMPONENT
========================================================= */

function Stat({ n, t }) {
    return (
        <div className="rounded-xl border border-white/10 bg-white/5 p-3.5 transition-all duration-300 hover:-translate-y-1 hover:bg-white/10 sm:rounded-2xl sm:p-5">

            <p className="font-display text-2xl font-bold text-lime-300 sm:text-3xl">
                {n}
            </p>

            <p className="mt-1 text-[10px] text-slate-400 sm:text-xs">
                {t}
            </p>

        </div>
    );
}


/* =========================================================
   SECTION TITLE
========================================================= */

function SectionTitle({
    eyebrow,
    title,
    dark = false,
}) {
    return (
        <div className="mb-7 sm:mb-9">

            <p
                className={`text-[10px] font-black uppercase tracking-[.2em] sm:text-xs ${dark
                        ? "text-lime-300"
                        : "text-lime-700"
                    }`}
            >
                {eyebrow}
            </p>

            <h2
                className={`mt-1.5 font-display text-3xl font-bold sm:text-4xl ${dark
                        ? "text-white"
                        : "text-slate-950"
                    }`}
            >
                {title}
            </h2>

        </div>
    );
}