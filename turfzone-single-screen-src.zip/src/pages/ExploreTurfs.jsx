import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";

import { useApp } from "../context/AppContext";
import TurfCard from "../components/TurfCard";
import { sports } from "../data/sports";
import { company } from "../data/company";

export default function ExploreTurfs() {
    const { turfs } = useApp();

    const [searchParams] = useSearchParams();

    const [sport, setSport] = useState(
        searchParams.get("sport") || ""
    );

    const [date, setDate] = useState(
        searchParams.get("date") || ""
    );

    const [max, setMax] = useState(2000);

    /*
     * Get sports from all facilities.
     */
    const availableSportIds = [
        ...new Set(
            turfs.flatMap((turf) => turf.sports || [])
        ),
    ];

    const availableSports = sports.filter((item) =>
        availableSportIds.includes(item.id)
    );

    /*
     * Filter every turf.
     */
    const filtered = useMemo(() => {
        return turfs.filter((turf) => {
            const matchesSport =
                !sport ||
                turf.sports?.includes(sport);

            const matchesPrice =
                Number(turf.price || 0) <= Number(max);

            const isEnabled =
                turf.enabled !== false;

            return (
                matchesSport &&
                matchesPrice &&
                isEnabled
            );
        });
    }, [turfs, sport, max]);

    const clear = () => {
        setSport("");
        setDate("");
        setMax(2000);
    };

    return (
        <main className="min-h-screen bg-slate-50 px-5 pb-20 pt-28 lg:px-8">
            <div className="mx-auto max-w-7xl">

                {/* HEADER */}
                <div className="mb-10 rounded-[2rem] bg-slate-950 p-7 text-white sm:p-10">
                    <p className="text-xs font-black uppercase tracking-[.2em] text-lime-300">
                        Our Facility
                    </p>

                    <h1 className="mt-2 font-display text-4xl font-bold sm:text-5xl">
                        Book {company.name}
                    </h1>

                    <p className="mt-3 max-w-2xl text-slate-300">
                        Choose from the playing spaces available at our company,
                        select your sport and find your preferred booking slot.
                    </p>

                    <div className="mt-6 flex flex-wrap gap-3">
                        <span className="rounded-full bg-white/10 px-4 py-2 text-sm font-semibold">
                            {company.address}
                        </span>

                        <span className="rounded-full bg-white/10 px-4 py-2 text-sm font-semibold">
                            {company.hours}
                        </span>
                    </div>
                </div>

                {/* FILTERS */}
                <div className="mb-8 grid gap-3 rounded-3xl border border-slate-200 bg-white p-4 shadow-sm md:grid-cols-3">

                    <select
                        value={sport}
                        onChange={(e) => setSport(e.target.value)}
                        className="rounded-xl bg-slate-100 px-4 py-3 text-sm outline-none"
                    >
                        <option value="">
                            All available sports
                        </option>

                        {availableSports.map((item) => (
                            <option
                                key={item.id}
                                value={item.id}
                            >
                                {item.name}
                            </option>
                        ))}
                    </select>

                    <input
                        type="date"
                        min={new Date().toISOString().slice(0, 10)}
                        value={date}
                        onChange={(e) =>
                            setDate(e.target.value)
                        }
                        className="rounded-xl bg-slate-100 px-4 py-3 text-sm outline-none"
                    />

                    <label className="rounded-xl bg-slate-100 px-4 py-3 text-sm font-semibold text-slate-600">
                        Maximum ₹{max}/hour

                        <input
                            type="range"
                            min="400"
                            max="2000"
                            step="50"
                            value={max}
                            onChange={(e) =>
                                setMax(Number(e.target.value))
                            }
                            className="mt-2 w-full accent-lime-500"
                        />
                    </label>

                    <button
                        onClick={clear}
                        type="button"
                        className="rounded-xl border border-slate-200 px-4 py-3 text-sm font-bold text-slate-700 md:col-span-3"
                    >
                        Clear Filters
                    </button>
                </div>

                {/* RESULT HEADER */}
                <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                        <p className="text-xs font-black uppercase tracking-[.2em] text-lime-700">
                            Available facilities
                        </p>

                        <h2 className="font-display text-3xl font-bold">
                            Our playing spaces
                        </h2>
                    </div>

                    <p className="text-sm font-semibold text-slate-500">
                        {filtered.length}{" "}
                        {filtered.length === 1
                            ? "facility"
                            : "facilities"}
                    </p>
                </div>

                {/* ALL TURFS */}
                {filtered.length > 0 ? (
                    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                        {filtered.map((turf) => (
                            <TurfCard
                                key={turf.id}
                                turf={turf}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="rounded-3xl border border-dashed border-slate-300 bg-white px-6 py-20 text-center">
                        <h2 className="font-display text-2xl font-bold">
                            No matching facility
                        </h2>

                        <p className="mt-2 text-slate-500">
                            Try another sport or price range.
                        </p>

                        <button
                            onClick={clear}
                            className="mt-6 rounded-xl bg-slate-950 px-5 py-3 text-sm font-bold text-white"
                        >
                            Clear Filters
                        </button>
                    </div>
                )}
            </div>
        </main>
    );
}